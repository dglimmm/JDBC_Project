package com.kh.personalP2.run;

import com.kh.personalP2.view.EmployeeMenu;

public class Run {

	public static void main(String[] args) {
		EmployeeMenu ep = new EmployeeMenu();
		ep.logintoMain();
	}
}
